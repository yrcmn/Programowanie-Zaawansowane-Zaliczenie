﻿using NUnit.Framework;
using MySqlConnector;
using System.Data;

namespace Zaliczenie_157846.Tests
{
    [TestFixture]
    public class Connection
    {
        private string _database = "wzorce_projekowe_zaliczenie_157846";
        private string _server = "localhost";
        private string _username = "root";
        private string _password = "sonny321!";

        [Test]
        public void TestPolaczenie()
        {
            string connectionString = $"server={_server};database={_database};uid={_username};password={_password}";

            using (var connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    Assert.AreEqual(ConnectionState.Open, connection.State);
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        connection.Close();
                }
            }
        }
    }
}
