﻿using NUnit.Framework;
using MySqlConnector;
using Zaliczenie_157846;
using System.Data;

namespace Zaliczenie_157846.Tests
{
    [TestFixture]
    public class Testy
    {
        private string _database = "wzorce_projekowe_zaliczenie_157846";
        private string _server = "localhost";
        private string _username = "root";
        private string _password = "sonny321!";
        private MySqlConnection _connection;
        private KategoriaProduktow _kategoriaProduktow;

        [SetUp]
        public void Setup()
        {
            _connection = new MySqlConnection($"server={_server};database={_database};uid={_username};password={_password}");
            _connection.Open();
            _kategoriaProduktow = new KategoriaProduktow(_connection);
        }

        [Test]
        public void TestDodawanieProduktu()
        {
            try
            {
                AddProdukt addProdukt = new AddProdukt(_connection);

                var command = new MySqlCommand("INSERT INTO Produkty (ID, Nazwa, Cena, Ilosc, Kategoria, Marka) VALUES (1000, 'TestProduct', 100, 100, 'Bluza', 'Nike')", _connection);
                command.ExecuteNonQuery();

                command = new MySqlCommand("SELECT * FROM Produkty WHERE ID = 1000", _connection);
                MySqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    Assert.AreEqual("TestProduct", reader["Nazwa"].ToString());
                    Assert.AreEqual(100, float.Parse(reader["Cena"].ToString()));
                    Assert.AreEqual(100, int.Parse(reader["Ilosc"].ToString()));
                    Assert.AreEqual("Bluza", reader["Kategoria"].ToString());
                    Assert.AreEqual("Nike", reader["Marka"].ToString());
                }
                else
                {
                    Assert.Fail("Produkt nie został dodany do bazy danych.");
                }

                reader.Close();

                command = new MySqlCommand("DELETE FROM Produkty WHERE ID = 1000", _connection);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Assert.Fail($"Wystąpił błąd podczas testu: {ex.Message}");
            }
        }

        [Test]
        public void TestUsunacProduktZBazyDanych()
        {
            try
            {
                int productId = 30;

                using (var connection = new MySqlConnection($"server={_server};database={_database};uid={_username};password={_password}"))
                {
                    connection.Open();

                    var command = new MySqlCommand("INSERT INTO Produkty (ID, Nazwa, Cena, Ilosc, Kategoria, Marka) VALUES (@ID, 'TestProductToDelete', 100, 100, 'Bluza', 'Nike')", connection);
                    command.Parameters.AddWithValue("@ID", productId);
                    command.ExecuteNonQuery();
                }

                _kategoriaProduktow.Usun(productId);

                using (var connection = new MySqlConnection($"server={_server};database={_database};uid={_username};password={_password}"))
                {
                    connection.Open();

                    var checkCommand = new MySqlCommand("SELECT * FROM Produkty WHERE ID = @ID", connection);
                    checkCommand.Parameters.AddWithValue("@ID", productId);
                    var reader = checkCommand.ExecuteReader();

                    Assert.IsFalse(reader.HasRows, "Produkt nie został usunięty z bazy danych");
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Assert.Fail($"Wystąpił błąd podczas testu: {ex.Message}");
            }
        }

        [Test]
        public void TestObslugiBazyDanych()
        {
            try
            {
                using (var connection = new MySqlConnection($"server={_server};database={_database};uid={_username};password={_password}"))
                {
                    connection.Open();

                    var command = new MySqlCommand("INSERT INTO Produkty (ID, Nazwa, Cena, Ilosc, Kategoria, Marka) VALUES (1005, 'TestProduct', 100, 10, 'Bluza', 'Nike')", connection);
                    command.ExecuteNonQuery();

                    command = new MySqlCommand("SELECT * FROM Produkty WHERE ID = 1005", connection);
                    var reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        Assert.AreEqual("TestProduct", reader["Nazwa"].ToString());
                    }
                    else
                    {
                        Assert.Fail("Produkt nie został dodany do bazy danych.");
                    }

                    reader.Close();

                    using (var deleteConnection = new MySqlConnection($"server={_server};database={_database};uid={_username};password={_password}"))
                    {
                        deleteConnection.Open();

                        var deleteCommand = new MySqlCommand("DELETE FROM Produkty WHERE ID = 1005", deleteConnection);
                        deleteCommand.ExecuteNonQuery();
                    }

                    command = new MySqlCommand("SELECT * FROM Produkty WHERE ID = 1005", connection);
                    reader = command.ExecuteReader();

                    Assert.IsFalse(reader.HasRows, "Produkt nie został usunięty z bazy danych.");

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Assert.Fail($"Wystąpił błąd podczas testu: {ex.Message}");
            }
        }

        [TearDown]
        public void TearDown()
        {
            _connection.Close();
            _connection.Dispose();
        }
    }
}
