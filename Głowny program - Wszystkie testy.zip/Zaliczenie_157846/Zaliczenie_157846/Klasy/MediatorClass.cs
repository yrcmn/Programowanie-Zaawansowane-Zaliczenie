﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zaliczenie_157846
{
    public interface IMediator
    {
        void Notify(object sender, string ev);
    }
    public class ConcreteMediator : IMediator
    {
        private ChoiseClass _choiseClass;
        private AddProdukt _addProdukt;
        private EditToDatabase _editToDatabase;
        private RunBuying _runBuying;
        private KategoriaProduktow _kategoriaProduktow;

        public ConcreteMediator(
            ChoiseClass choiseClass,
            AddProdukt addProdukt,
            EditToDatabase editToDatabase,
            RunBuying runBuying,
            KategoriaProduktow kategoriaProduktow)
        {
            _choiseClass = choiseClass;
            _choiseClass.SetMediator(this);
            _addProdukt = addProdukt;
            _addProdukt.SetMediator(this);
            _editToDatabase = editToDatabase;
            _editToDatabase.SetMediator(this);
            _runBuying = runBuying;
            _runBuying.SetMediator(this);
            _kategoriaProduktow = kategoriaProduktow;
            _kategoriaProduktow.SetMediator(this);
        }

        public void Notify(object sender, string ev)
        {
            if (ev == "MainWybor")
            {
                _choiseClass.MainWybor();
            }
            else if (ev == "AddProdukt")
            {
                _addProdukt.dodajProdukt();
            }
            else if (ev == "EditToDatabase")
            {
                _editToDatabase.Wybor();
            }
            else if (ev == "RunBuying")
            {
                _runBuying.AddToBasket();
            }
            else if (ev == "WyswietlProdukty")
            {
                _kategoriaProduktow.Wyswietl(0);
            }
        }
    }
}
