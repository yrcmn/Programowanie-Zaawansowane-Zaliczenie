﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;

namespace Zaliczenie_157846
{
    public class EditToDatabase
    {
        private readonly MySqlConnection connection;
        private IMediator _mediator;

        public EditToDatabase(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void Wybor()
        {
            Console.Clear();
            Console.WriteLine("Wybierz opcję:");
            Console.WriteLine("1. Wyświetl Produkty");
            Console.WriteLine("2. Usuń Produkt według ID");
            Console.WriteLine("3. Dodaj nowy produkt");
            int wybor = int.Parse(Console.ReadLine());

            switch (wybor)
            {
                case 1:
                    _mediator.Notify(this, "WyswietlProdukty");
                    break;
                case 2:
                    Console.WriteLine("Podaj ID produktu do usunięcia:");
                    int id = int.Parse(Console.ReadLine());
                    KategoriaProduktow usuwanieProduktow_ob = new KategoriaProduktow(connection);
                    usuwanieProduktow_ob.Usun(id);
                    break;
                case 3:
                    AddProdukt fabrykaAbstrakcyjna = new AddProdukt(connection);
                    fabrykaAbstrakcyjna.dodajProdukt();
                    break;
            }
        }
    }

    public interface IKategoriaProduktow
    {
        void Usun(int id);
        void Wyswietl(int poziom);
    }
    public class Produkt : IKategoriaProduktow
    {
        private string nazwa;

        public Produkt(string nazwa)
        {
            this.nazwa = nazwa;
        }

        public void Usun(int id)
        {
            Console.WriteLine("Nie można usunąć z produktu.");
        }

        public void Wyswietl(int poziom)
        {
            Console.WriteLine(new string('-', poziom) + "+ " + nazwa);
        }
    }
    public class KategoriaProduktow : IKategoriaProduktow
    {
        private readonly MySqlConnection connection;
        private List<IKategoriaProduktow> id = new List<IKategoriaProduktow>();
        private IMediator _mediator;

        public KategoriaProduktow(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void Usun(int id)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                string query = "DELETE FROM Produkty WHERE id = @ID";
                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@ID", id);

                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        Console.WriteLine("Rekord został pomyślnie usunięty.");
                    }
                    else
                    {
                        Console.WriteLine("Nie znaleziono rekordu o podanym ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Wystąpił błąd: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void Wyswietl(int poziom)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                string query = "SELECT * FROM Produkty";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    MySqlDataReader reader = command.ExecuteReader();

                    int[] columnWidths = new int[reader.FieldCount];

                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            int length = reader[i].ToString().Length;
                            if (length > columnWidths[i])
                            {
                                columnWidths[i] = length;
                            }
                        }
                    }
                    reader.Close();

                    reader = command.ExecuteReader();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        Console.Write(reader.GetName(i).PadLeft(columnWidths[i]) + "   ");
                    }
                    Console.WriteLine();

                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.Write(reader[i].ToString().PadRight(columnWidths[i]) + "   ");
                        }
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Wystąpił błąd: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
