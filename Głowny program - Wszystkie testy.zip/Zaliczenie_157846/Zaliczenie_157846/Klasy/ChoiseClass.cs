﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zaliczenie_157846
{
    public class ChoiseClass
    {
        private readonly MySqlConnection connection;
        private IMediator _mediator;

        public ChoiseClass(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void MainWybor()
        {
            Console.WriteLine("1: Sprzedawca \n2: Klient");
            int wybor = int.Parse(Console.ReadLine());
            Console.Clear();
            switch (wybor)
            {
                case 1:
                    _mediator.Notify(this, "EditToDatabase");
                    break;
                case 2:
                    _mediator.Notify(this, "WyswietlProdukty");
                    _mediator.Notify(this, "RunBuying");
                    break;
            }
        }
    }
}
