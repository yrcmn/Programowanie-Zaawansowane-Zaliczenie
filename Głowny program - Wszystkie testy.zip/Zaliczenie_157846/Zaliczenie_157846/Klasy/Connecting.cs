﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zaliczenie_157846
{
    public class Connection
    {
        protected readonly MySqlConnection connection;
        public Connection(MySqlConnection connection)
        {
            this.connection = connection;
        }
    }

    internal class Connecting
    {
        string password;
        string username;
        string table;
        string database;

        public Connecting(string database, string table, string username, string password)
        {
            this.database = database;
            this.table = table;
            this.username = username;
            this.password = password;
        }

        public void Connect()
        {
            try
            {
                string query = $"Data Source={database}; Initial Catalog={table}; User ID={username}; Password={password}";

                MySqlConnection connection = new MySqlConnection(query);
                ChoiseClass switchClass = new ChoiseClass(connection);

                connection.Open();
                switchClass.MainWybor();
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
