﻿using MySqlConnector;
using System;
using System.Collections.Generic;
//polecenie
namespace Zaliczenie_157846
{
    public class RunBuying
    {
        private readonly MySqlConnection connection;
        private IMediator _mediator;

        public RunBuying(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void AddToBasket()
        {
            Console.Write("\nIle produktów chcesz dodać?");
            int ileProduktow = int.Parse(Console.ReadLine());
            Koszyk koszyk = new Koszyk();

            for (int i = 0; i < ileProduktow; i++)
            {
                ICommand dodajProduktDoKoszykaCommand = new DodajProduktDoKoszykaCommand(koszyk, connection);
                dodajProduktDoKoszykaCommand.Execute();

                koszyk.Wyswietl();
                Console.WriteLine("Łączna suma: {0}", koszyk.SumaCen());
            }
        }
    }

    public interface ICommand
    {
        void Execute();
    }

    public class DodajProduktDoKoszykaCommand : ICommand
    {
        private readonly Koszyk koszyk;
        private readonly MySqlConnection connection;

        public DodajProduktDoKoszykaCommand(Koszyk koszyk, MySqlConnection connection)
        {
            this.koszyk = koszyk;
            this.connection = connection;
        }

        public void Execute()
        {
            koszyk.DodajProduktDoKoszyka(connection);
        }
    }

    public class Koszyk
    {
        private readonly Dictionary<int, Produkt1> koszyk = new Dictionary<int, Produkt1>();

        public void Wyswietl()
        {
            foreach (var keyValuePair in koszyk)
            {
                Console.WriteLine($"ID: {keyValuePair.Key}, Nazwa: {keyValuePair.Value.Nazwa}, Cena: {keyValuePair.Value.Cena}");
            }
        }

        public void DodajProduktDoKoszyka(MySqlConnection connection)
        {
            try
            {
                Console.WriteLine("DodajProduktDoKoszyka (ID):");
                int idProduktu = int.Parse(Console.ReadLine());

                string query = "SELECT Nazwa, Cena FROM Produkty WHERE ID = @ID";

                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@ID", idProduktu);

                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string nazwaProduktu = reader.GetString(0);
                            float Cena = reader.GetFloat(1);
                            Produkt1 produkt = new Produkt1(idProduktu, nazwaProduktu, Cena);
                            koszyk.Add(idProduktu, produkt);
                        }
                        else
                        {
                            Console.WriteLine($"Produkt o ID {idProduktu} nie istnieje w bazie danych.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Wystąpił błąd: {ex.Message}");
            }
        }

        public float SumaCen()
        {
            float suma = 0;
            foreach (var i in koszyk.Values)
            {
                suma = suma + i.Cena;
            }
            return suma;
        }
    }
    public class Produkt1
    {
        public int ID { get; set; }
        public string Nazwa { get; set; }
        public float Cena { get; set; }

        public Produkt1(int ID, string Nazwa, float Cena)
        {
            this.ID = ID;
            this.Nazwa = Nazwa;
            this.Cena = Cena;
        }
    }
}