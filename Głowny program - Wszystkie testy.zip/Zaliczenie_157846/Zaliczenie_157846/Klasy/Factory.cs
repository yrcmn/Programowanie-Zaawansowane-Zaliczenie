﻿using MySqlConnector;
using System;
using System.Data;

namespace Zaliczenie_157846
{
    public class AddProdukt
    {
        private readonly MySqlConnection connection;
        private IMediator _mediator;

        public AddProdukt(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void SetMediator(IMediator mediator)
        {
            _mediator = mediator;
        }

        public void dodajProdukt()
        {
            Console.Clear();
            Console.WriteLine("1: Buty\n2: Górna część garderoby\n3: Dolna część garderoby");
            Console.Write("Jaki produkt chcesz dodać? ");
            int wybor = int.Parse(Console.ReadLine());

            IProduktFabryka fabryka = null;

            switch (wybor)
            {
                case 1:
                    fabryka = new ButyFabryka(connection);
                    break;
                case 2:
                    fabryka = new KoszulkaFabryka(connection);
                    break;
                case 3:
                    fabryka = new SpodnieFabryka(connection);
                    break;
                default:
                    Console.WriteLine("Niepoprawny wybór produktu.");
                    return;
            }

            Console.Write("Podaj nazwę produktu: ");
            string name = Console.ReadLine();
            Console.Write("Podaj cenę: ");
            float cena = float.Parse(Console.ReadLine());
            Console.Write("Podaj ilość: ");
            int ilosc = int.Parse(Console.ReadLine());
            Console.Write("Podaj kategorię: ");
            string kategoria = Console.ReadLine();
            Console.Write("Podaj markę: ");
            string marka = Console.ReadLine();

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                string query = "INSERT INTO Produkty (Nazwa, Cena, Ilosc, Kategoria, Marka) VALUES (@name, @cena, @ilosc, @kategoria, @marka)";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@cena", cena);
                cmd.Parameters.AddWithValue("@ilosc", ilosc);
                cmd.Parameters.AddWithValue("@kategoria", kategoria);
                cmd.Parameters.AddWithValue("@marka", marka);

                int result = cmd.ExecuteNonQuery();

                if (result > 0 && cena > 0 && ilosc > 0)
                {
                    Console.Clear();
                    Console.WriteLine("Produkt został dodany do bazy danych.");
                    IProdukt produkt = fabryka.StworzProdukt();
                    produkt.DodajProdukt();
                }
                else
                {
                    Console.WriteLine("Błąd podczas dodawania produktu.");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Wystąpił błąd: " + ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }


        public interface IProdukt
    {
        void DodajProdukt();
    }

    public interface IProduktFabryka
    {
        IProdukt StworzProdukt();
    }

    // Produkty

    public class Buty : IProdukt
    {
        private readonly MySqlConnection connection;

        public Buty(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void DodajProdukt()
        {
            Console.WriteLine("Pomyślnie dodano buty do bazy danych");
        }
    }

    public class Koszulka : IProdukt
    {
        private readonly MySqlConnection connection;

        public Koszulka(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void DodajProdukt()
        {
            Console.WriteLine("Pomyślnie dodano koszulkę do bazy danych");
        }
    }

    public class Spodnie : IProdukt
    {
        private readonly MySqlConnection connection;

        public Spodnie(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public void DodajProdukt()
        {
            Console.WriteLine("Pomyślnie dodano spodnie do bazy danych");
        }
    }

    // Fabryka

    public class ButyFabryka : IProduktFabryka
    {
        private readonly MySqlConnection connection;

        public ButyFabryka(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public IProdukt StworzProdukt()
        {
            return new Buty(connection);
        }
    }

    public class KoszulkaFabryka : IProduktFabryka
    {
        private readonly MySqlConnection connection;

        public KoszulkaFabryka(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public IProdukt StworzProdukt()
        {
            return new Koszulka(connection);
        }
    }

    public class SpodnieFabryka : IProduktFabryka
    {
        private readonly MySqlConnection connection;

        public SpodnieFabryka(MySqlConnection connection)
        {
            this.connection = connection;
        }

        public IProdukt StworzProdukt()
        {
            return new Spodnie(connection);
        }
    }
}
