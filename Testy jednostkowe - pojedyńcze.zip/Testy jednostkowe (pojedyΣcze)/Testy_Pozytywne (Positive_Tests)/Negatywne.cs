﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testy_Negatywne
{
    internal class Negatywne
    {
        public int Dzielenie(int a, int b)
        {
            return checked(a / b);
        }

        public int PoleTrojkata(int a, int h)
        {
            if(a <= 0 || h <= 0)
            {
                throw new ArgumentOutOfRangeException("a i h nie mogą być mniejsze od 0.");
            }
            return checked ((a * h) / 2);
        }   
    }
    public class AuthService
    {
        private readonly IDictionary<string, string> _referencjeUzytkownika;

        public AuthService(IDictionary<string, string> referencjeUzytkownika)
        {
            _referencjeUzytkownika = referencjeUzytkownika;
        }

        public bool Login(string username, string password)
        {
            return _referencjeUzytkownika.TryGetValue(username, out var storedPassword) && storedPassword == password;
        }
    }

    public class ListService
    {
        public T FindElement<T>(IList<T> list, T element)
        {
            //list.Add(element);
            if(list == null || !list.Any())
            {
                throw new InvalidOperationException("List is empty");
            }

            return list.First(e => e.Equals(element));
        }
    }
}
