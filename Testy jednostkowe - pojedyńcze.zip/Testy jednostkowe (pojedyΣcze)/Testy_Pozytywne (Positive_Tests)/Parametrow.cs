﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testy_Pozytywne
{
    internal class Parametry
    {
        public int Dodaj_Integery(int a, int b)
        {
            return a + b;
        }

        public double Dodaj_Doublety(double a, double b)
        {
            return a + b;
        }

        public string Dodaj_Stringi(string a, string b)
        {
            return a + b;
        }

        public string Dodaj_Daty(string date, int daysToAdd)
        {
            DateTime dt = DateTime.Parse(date);
            return dt.AddDays(daysToAdd).ToString("yyyy-MM-dd");
        }
    }
    public class DataAddProvider
    {
        public static IEnumerable<TestCaseData> TestData
        {
            get
            {
                yield return new TestCaseData("2024-05-23", 5).Returns("2024-05-23");
            }
        }
    }
}
