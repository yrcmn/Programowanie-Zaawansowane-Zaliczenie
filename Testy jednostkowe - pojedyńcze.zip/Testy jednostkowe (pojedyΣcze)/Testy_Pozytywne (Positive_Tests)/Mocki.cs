﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testy_Mocki
{
    public interface IDataService
    {
        string GetData(int id);
    }

    public class DataProcessor
    {
        private readonly IDataService _dataService;

        public DataProcessor(IDataService dataService)
        {
            _dataService = dataService;
        }

        public string PrzetwarzajDane(int id)
        {
            return _dataService.GetData(id);
        }
    }
}
