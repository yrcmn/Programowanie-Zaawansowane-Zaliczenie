﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using Testy_Mocki;

namespace Testy_Mocki.Tests
{
    [TestFixture]
    internal class TestyZMockami
    {
        [Test]
        public void MockTest1()
        {
            var mockDataService = new Mock<IDataService>();
            mockDataService.Setup(ds => ds.GetData(It.IsAny<int>())).Returns("Test data");

            var processor = new DataProcessor(mockDataService.Object);
            for (int i = 0; i <= 2; i++)
            {
                var result = processor.PrzetwarzajDane(1);
                Assert.AreEqual("Test data", result);

            }
            mockDataService.Verify(ds => ds.GetData(1), Times.AtLeast(3));
        }
    }
}
