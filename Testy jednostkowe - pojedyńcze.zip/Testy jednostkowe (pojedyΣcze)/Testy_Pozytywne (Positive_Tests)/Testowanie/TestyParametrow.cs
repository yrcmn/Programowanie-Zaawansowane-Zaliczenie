﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using Testy_Pozytywne;

namespace Testy_Parametrow.Tests
{
    [TestFixture]
    internal class TestyParametrow
    {
        private Parametry _parametry;

        [SetUp]
        public void Setup()
        {
            _parametry = new Parametry();
        }

        [Test]
        [TestCase(1, 2, 3)]
        [TestCase(10, 100, 110)]
        [TestCase(3030, 10, 3040)]
        public void TestParametrow1(int a, int b, int expectedResult)
        {
            var result = _parametry.Dodaj_Integery(a, b);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        [TestCase("a", "b", "ab")]
        [TestCase("AB", "BA", "ABBA")]
        [TestCase("Q", "ueen", "Queen")]
        [TestCase("The", "Beatles", "TheBeatles")]
        [TestCase("a-", "ha", "a-ha")]
        public void TestParametrow2(string a, string b, string expectedString)
        {
            var result = _parametry.Dodaj_Stringi(a, b);
            Assert.AreEqual(expectedString, result);
        }

        [Test]
        [TestCase("2024-05-23", 4, "2024-05-27")]
        [TestCase("2024-05-31", 5, "2024-06-05")]
        public void TestParametrow(string date, int daysToAdd, string expectedResult)
        {
            var result = _parametry.Dodaj_Daty(date, daysToAdd);
            Assert.AreEqual(expectedResult, result);
        }
    }
}
