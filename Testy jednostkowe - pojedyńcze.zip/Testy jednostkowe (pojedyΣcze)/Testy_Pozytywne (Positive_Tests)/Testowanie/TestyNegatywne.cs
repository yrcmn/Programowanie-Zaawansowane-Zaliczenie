﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Testy_Negatywne;
using NUnit.Framework;

namespace Testy_Negatywne.Tests
{
    [TestFixture]
    internal class Programs
    {
        private Negatywne program;
        [SetUp]
        public void SetUp()
        {
            program = new Negatywne();
        }

        [Test]
        public void TestNegatywny1()
        {
            Assert.Throws<DivideByZeroException>(() => program.Dzielenie(10,0));
            Assert.Throws<DivideByZeroException>(() => program.Dzielenie(312, 0));
        }
        [Test]
        [TestCase(-1,1)]
        [TestCase(-32, 2)]
        [TestCase(3, -8)]
        public void TestNegatywny2(int a, int b)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => program.PoleTrojkata(a,b));
        }   
    }

    [TestFixture]
    internal class Programs2
    {
        private AuthService _authService;
        
        [SetUp]
        public void Setup()
        {
            var userReferences = new Dictionary<string, string>
            {
                {"sonny", "crockett" }
            };
            _authService = new AuthService(userReferences);
        }

        [Test]
        public void TestNegatywny3()
        {
            var result = _authService.Login("sonny", "burnett");
            Assert.IsFalse(result);
        }
    }
    [TestFixture]
    internal class Programs3
    {
        private ListService _listService;

        [SetUp]
        public void Setup()
        {
            _listService = new ListService();
        }
        //ten test sprawdza, czy metoda wyszukiwania elementu w liście rzuca wyjątek, gdy lista jest pusta.
        [Test]
        public void TestNegatywny4()
        {
            var emptyList = new List<int>();

            Assert.Throws<InvalidOperationException>(() => _listService.FindElement(emptyList, 5));
        }

    }
}
