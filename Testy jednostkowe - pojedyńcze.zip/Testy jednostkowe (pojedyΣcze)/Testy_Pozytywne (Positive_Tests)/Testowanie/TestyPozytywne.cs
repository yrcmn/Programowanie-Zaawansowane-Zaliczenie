using NUnit.Framework;
using Testy_Pozytywne;

namespace Testy_Pozytywne.Tests
{
    [TestFixture]
    internal class Tests
    {
        private Programs program;

        [SetUp]
        public void Setup()
        {
            program = new Programs();
        }

        [Test]
        public void PositiveTest1()
        {
            var result = program.Dodawanie(1,2);
            Assert.AreEqual(3, result);
        }

        [Test]
        public void PositiveTest2()
        {
            var result = program.Dzielenie(20, 5);
            Assert.AreEqual(4, result);
        }

        [Test] 
        public void PositiveTest3()
        {
            var result = program.Dodawanie(5, 5);
            result = program.Dzielenie(result, 2);
            Assert.AreEqual(5, result);
        }

        [Test]
        public void PositiveTest4()
        {
            var result = program.PoleSzescianu(3);
            Assert.AreEqual(54, result);   
        }

        [Test]
        public void PositiveTest5()
        {
            var result = program.OdwrocString("siema");
            Assert.AreEqual("ameis", result);
        }
    }
}