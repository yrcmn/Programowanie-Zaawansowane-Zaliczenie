﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testy_Pozytywne
{
    class Programs
    {
        public int Dodawanie(int a, int b)
        {
            return checked(a + b);
        }

        public int Dzielenie(int a, int b)
        {
            return checked(a / b);
        }

        public int PoleSzescianu(int a)
        {
            return checked(6 * (a * a));
        }

        public string OdwrocString(string a)
        {
            char[] znakowLista = a.ToCharArray();
            for (int i = 0, j = a.Length - 1; i < j; i++, j--)
            {
                znakowLista[i] = a[j];
                znakowLista[j] = a[i];
            }
            string reversedString = new string(znakowLista);
            return reversedString;
        }
    }
}
